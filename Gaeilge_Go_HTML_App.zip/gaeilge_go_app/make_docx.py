from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.enum.text import WD_BREAK


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)


def set_cell_margins(cell, top=120, start=120, bottom=120, end=120):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def add_heading(doc, text, level=1, color='169B62'):
    p = doc.add_paragraph()
    p.style = f'Heading {level}'
    run = p.add_run(text)
    run.font.color.rgb = RGBColor.from_string(color)
    return p


def add_word_table(doc, title, items):
    add_heading(doc, title, level=2, color='F68B1F')
    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    table.autofit = False
    widths = [Inches(1.7), Inches(2.2), Inches(2.0), Inches(1.6)]
    headers = ['Ірландська', 'Українська', 'Вимова', 'Тема']
    hdr = table.rows[0].cells
    for i, text in enumerate(headers):
        hdr[i].width = widths[i]
        hdr[i].text = text
        set_cell_shading(hdr[i], 'EAF6EE' if i % 2 else 'FFF2E5')
        set_cell_margins(hdr[i], 120, 120, 120, 120)
        hdr[i].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        for p in hdr[i].paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                r.font.bold = True
                r.font.size = Pt(10.5)
    for item in items:
        row = table.add_row().cells
        values = [item['irish'], item['uk'], item['pron'], item['category']]
        for i, value in enumerate(values):
            row[i].width = widths[i]
            row[i].text = value
            set_cell_margins(row[i], 110, 110, 110, 110)
            row[i].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for p in row[i].paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i < 3 else WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:
                    r.font.size = Pt(10)
    doc.add_paragraph('')


def add_sentence_table(doc, items):
    add_heading(doc, 'Речення для тренування', level=2, color='169B62')
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    table.autofit = False
    widths = [Inches(4.4), Inches(2.8)]
    headers = ['Ірландське речення', 'Український зміст']
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.width = widths[i]
        cell.text = h
        set_cell_shading(cell, 'EAF6EE' if i else 'FFF2E5')
        set_cell_margins(cell, 120, 120, 120, 120)
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                r.font.bold = True
                r.font.size = Pt(10.5)
    for sentence, hint in items:
        row = table.add_row().cells
        row[0].text = sentence
        row[1].text = hint
        for i, cell in enumerate(row):
            cell.width = widths[i]
            set_cell_margins(cell, 110, 110, 110, 110)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.size = Pt(10.5)
    doc.add_paragraph('')


doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.7)
sec.bottom_margin = Inches(0.7)
sec.left_margin = Inches(0.75)
sec.right_margin = Inches(0.75)

styles = doc.styles
styles['Normal'].font.name = 'Arial'
styles['Normal'].font.size = Pt(10.5)
styles['Heading 1'].font.name = 'Arial'
styles['Heading 1'].font.size = Pt(22)
styles['Heading 1'].font.bold = True
styles['Heading 2'].font.name = 'Arial'
styles['Heading 2'].font.size = Pt(14)
styles['Heading 2'].font.bold = True

# Cover
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Gaeilge Go')
r.font.size = Pt(26)
r.font.bold = True
r.font.color.rgb = RGBColor.from_string('169B62')

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Мій словник ірландської мови')
r.font.size = Pt(17)
r.font.bold = True
r.font.color.rgb = RGBColor.from_string('F68B1F')

for line in [
    'Зібрано на основі вже вивчених слів і фраз.',
    'Документ підготовлено як супровід до HTML-застосунку для GitHub Pages.',
    'Тут є слова, короткі граматичні шаблони, нові базові слова та речення для практики.'
]:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(line)
    run.font.size = Pt(11.5)

# Flag band via table
flag = doc.add_table(rows=1, cols=3)
flag.alignment = WD_TABLE_ALIGNMENT.CENTER
flag.autofit = False
for i, color in enumerate(['F68B1F', 'F4F4F4', '169B62']):
    cell = flag.rows[0].cells[i]
    cell.width = Inches(2.15)
    cell.text = ''
    set_cell_shading(cell, color)
    set_cell_margins(cell, 40, 40, 40, 40)

doc.add_paragraph('')

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('Структура документа')
run.font.bold = True
run.font.size = Pt(12)
run.font.color.rgb = RGBColor.from_string('169B62')
for item in [
    '1. Привітання та базові слова',
    '2. Форми з Tá / Is ainm dom / Is féidir...',
    '3. Великодня і християнська лексика',
    '4. Красиві абстрактні слова',
    '5. Нові щоденні слова',
    '6. Готові речення для вправ'
]:
    p = doc.add_paragraph(style='List Bullet')
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.add_run(item)

# Page break

doc.add_page_break()

core_words = [
    {'irish':'Dia dhuit','uk':'привіт','pron':'діа ґвич','category':'Привітання'},
    {'irish':'Dia is Muire dhuit','uk':'відповідь на привітання','pron':'діа іс мурє ґвич','category':'Привітання'},
    {'irish':'Slán','uk':'бувай','pron':'слоон','category':'Привітання'},
    {'irish':'Go raibh maith agat','uk':'дякую','pron':'ґо рев ма агат','category':'Привітання'},
    {'irish':'Tá fáilte romhat','uk':'будь ласка','pron':'та фольче роват','category':'Привітання'},
    {'irish':'duine','uk':'людина','pron':'динє','category':'Базові слова'},
    {'irish':'cara','uk':'друг','pron':'кара','category':'Базові слова'},
    {'irish':'teach','uk':'дім','pron':'тях','category':'Базові слова'},
    {'irish':'uisce','uk':'вода','pron':'ішке','category':'Базові слова'},
    {'irish':'arán','uk':'хліб','pron':'араан','category':'Базові слова'},
    {'irish':'ainm','uk':'ім’я','pron':'анім','category':'Базові слова'},
    {'irish':'páiste','uk':'дитина','pron':'паште','category':'Базові слова'},
]
add_word_table(doc, 'Привітання та базові слова', core_words)

grammar_words = [
    {'irish':'Tá mé','uk':'я є','pron':'та мє','category':'Tá'},
    {'irish':'Tá tú','uk':'ти є','pron':'та ту','category':'Tá'},
    {'irish':'Tá sé','uk':'він є','pron':'та ше','category':'Tá'},
    {'irish':'Tá sí','uk':'вона є','pron':'та ші','category':'Tá'},
    {'irish':'Tá muid / Táimid','uk':'ми є','pron':'та мидь','category':'Tá'},
    {'irish':'Tá sibh','uk':'ви є','pron':'та шив','category':'Tá'},
    {'irish':'Tá siad','uk':'вони є','pron':'та шід','category':'Tá'},
    {'irish':'Is ainm dom','uk':'мене звати','pron':'іс анім дум','category':'Ім’я'},
    {'irish':'Is féidir liom','uk':'я можу','pron':'іс фєдір ліом','category':'Можу'},
    {'irish':'Is féidir leat','uk':'ти можеш','pron':'іс фєдір лят','category':'Можу'},
    {'irish':'Ní féidir liom','uk':'я не можу','pron':'ні фєдір ліом','category':'Заперечення'},
    {'irish':'An féidir leat...?','uk':'чи можеш ти...?','pron':'ан фєдір лят','category':'Питання'},
]
add_word_table(doc, 'Короткі граматичні шаблони', grammar_words)

easter_words = [
    {'irish':'An Cháisc','uk':'Великдень / Пасха','pron':'ан хашкь','category':'Свято'},
    {'irish':'cáca Cásca','uk':'паска','pron':'каака кооска','category':'Свято'},
    {'irish':'ubh Cásca','uk':'великоднє яйце','pron':'ув кооска','category':'Свято'},
    {'irish':'Críostaí','uk':'християнин','pron':'кріістіі','category':'Віра'},
    {'irish':'an Chríostaíocht','uk':'християнство','pron':'ан хріістаїхт','category':'Віра'},
    {'irish':'Dia','uk':'Бог','pron':'діа','category':'Віра'},
    {'irish':'Íosa','uk':'Ісус','pron':'іса','category':'Віра'},
    {'irish':'eaglais','uk':'церква','pron':'агліш','category':'Віра'},
    {'irish':'paidir','uk':'молитва','pron':'паджір','category':'Віра'},
    {'irish':'Aiséirí','uk':'воскресіння','pron':'ашееріі','category':'Віра'},
    {'irish':'an chros','uk':'хрест','pron':'ан хрос','category':'Віра'},
    {'irish':'anam','uk':'душа','pron':'анам','category':'Віра'},
]
add_word_table(doc, 'Великодня і християнська лексика', easter_words)

aesthetic_words = [
    {'irish':'solas','uk':'світло','pron':'солас','category':'Красиві слова'},
    {'irish':'grá','uk':'любов','pron':'ґраа','category':'Красиві слова'},
    {'irish':'síocháin','uk':'мир, спокій','pron':'шііхаань','category':'Красиві слова'},
    {'irish':'dóchas','uk':'надія','pron':'доохас','category':'Красиві слова'},
    {'irish':'beatha','uk':'життя','pron':'бяха','category':'Красиві слова'},
    {'irish':'fírinne','uk':'правда','pron':'фірінє','category':'Красиві слова'},
    {'irish':'croí','uk':'серце','pron':'крі','category':'Красиві слова'},
    {'irish':'sonas','uk':'щастя','pron':'сонас','category':'Красиві слова'},
    {'irish':'muinín','uk':'довіра','pron':'муйнінь','category':'Красиві слова'},
    {'irish':'cineáltas','uk':'доброта','pron':'кінєалтас','category':'Красиві слова'},
    {'irish':'beannaithe','uk':'благословенний','pron':'бянахе','category':'Красиві слова'},
    {'irish':'solas Dé','uk':'світло Бога','pron':'солас дзе','category':'Красиві слова'},
]
add_word_table(doc, 'Красиві слова та абстрактні поняття', aesthetic_words)

new_words = [
    {'irish':'madra','uk':'собака','pron':'мадра','category':'Нові слова'},
    {'irish':'cat','uk':'кіт','pron':'кат','category':'Нові слова'},
    {'irish':'scoil','uk':'школа','pron':'сколь','category':'Нові слова'},
    {'irish':'leabhar','uk':'книга','pron':'ляур / ляуар','category':'Нові слова'},
    {'irish':'bia','uk':'їжа','pron':'бія','category':'Нові слова'},
    {'irish':'teaghlach','uk':'сім’я','pron':'тяллах / тьяулах','category':'Нові слова'},
]
add_word_table(doc, 'Нові щоденні слова', new_words)

sentences = [
    ('Tá mé go maith.', 'Я добре.'),
    ('Tá tú tuirseach.', 'Ти втомлений / втомлена.'),
    ('Tá sí sásta.', 'Вона щаслива.'),
    ('Is ainm dom Davyd.', 'Мене звати Давид.'),
    ('Tá an Cháisc ag teacht.', 'Великдень наближається.'),
    ('Tá dóchas agam.', 'Я маю надію.'),
    ('Tá an eaglais oscailte.', 'Церква відкрита.'),
    ('Is féidir liom dul.', 'Я можу піти.'),
    ('Ní féidir liom é a dhéanamh.', 'Я не можу це зробити.'),
    ('An féidir leat cabhrú liom?', 'Можеш допомогти мені?'),
    ('Tá bia agus uisce ann.', 'Там є їжа і вода.'),
    ('Tá grá i mo chroí.', 'У моєму серці є любов.'),
]
add_sentence_table(doc, sentences)

add_heading(doc, 'Нотатка', level=2, color='F68B1F')
p = doc.add_paragraph()
p.add_run('Цей документ створено як зручний словник для повторення, ').font.size = Pt(10.5)
p.add_run('а HTML-застосунок Gaeilge Go ').font.bold = True
p.add_run('можна використовувати для інтерактивного тренування перекладу та складання речень.').font.size = Pt(10.5)

out = '/mnt/data/Gaeilge_Go_Slovnyk.docx'
doc.save(out)
print(out)
